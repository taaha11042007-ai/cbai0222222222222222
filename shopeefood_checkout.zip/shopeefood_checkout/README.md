# ShopeeFood Checkout

## 1. Phân tích bài toán I/O

### Input

| Biến | Kiểu dữ liệu | Ý nghĩa |
|---|---|---|
| `ma_mon_an` | `int` | Mã món ăn |
| `don_gia` | `float` | Đơn giá món ăn |
| `so_luong_dat` | `int` | Số lượng đặt mua |
| `khoang_cach_km` | `float` | Khoảng cách giao hàng |
| `is_peak` | `int` | 1: cao điểm, 0: bình thường |
| `is_store_open` | `int` | 1: cửa hàng mở, 0: cửa hàng đóng |
| `ton_kho` | `int` | Số lượng món còn trong kho |
| `loai_tai_khoan` | `char` | `V`: VIP, `N`: Normal |

### Output

Chương trình hiển thị:
- Tổng tiền món ăn.
- Phí giao hàng cơ bản.
- Giảm giá Freeship.
- Phụ phí giờ cao điểm.
- Trạng thái hợp lệ của đơn hàng.
- Tổng số tiền thanh toán cuối cùng.

## 2. Công thức tính toán

### Tiền món ăn

```text
Subtotal = Đơn giá × Số lượng đặt
```

Trong C:

```c
float subtotal = don_gia * so_luong_dat;
```

### Phí giao hàng cơ bản

```text
Base Shipping Fee = Khoảng cách × 5000
```

Trong C:

```c
float base_shipping_fee = khoang_cach_km * 5000.0;
```

### Điều kiện Freeship

Đơn hàng đạt Freeship khi:

```text
(Subtotal >= 100000 AND Khoảng cách <= 5)
OR
Tài khoản là VIP
```

Trong C:

```c
int is_freeship =
    ((subtotal >= 100000.0) && (khoang_cach_km <= 5.0))
    || (loai_tai_khoan == 'V');
```

Biểu thức logic trong C trả về `1` khi đúng và `0` khi sai.

### Giảm giá Freeship

Mức giảm tối đa là 15.000 VNĐ và không được vượt quá phí giao hàng cơ bản.

```c
float freeship_discount =
    15000.0 * is_freeship * (base_shipping_fee >= 15000.0)
    + base_shipping_fee * is_freeship * (base_shipping_fee < 15000.0);
```

Biểu thức trên dùng kết quả Boolean `0/1` để xác định mức giảm mà không cần `if/else`.

### Phụ phí giờ cao điểm

```text
Peak Surcharge = 10000 × is_peak
```

Trong C:

```c
float peak_surcharge = 10000.0 * is_peak;
```

## 3. Điều kiện hợp lệ của đơn hàng

Đơn hàng hợp lệ khi tất cả điều kiện đều đúng:

```text
Cửa hàng mở
AND
Tồn kho >= Số lượng đặt
AND
Số lượng đặt > 0
AND
Đơn giá > 0
```

Trong C:

```c
int is_valid =
    (is_store_open == 1)
    && (ton_kho >= so_luong_dat)
    && (so_luong_dat > 0)
    && (don_gia > 0);
```

Kết quả là `1` nếu tất cả điều kiện đúng, ngược lại là `0`.

## 4. Tổng tiền cuối cùng

Công thức:

```text
Final Amount =
(Subtotal + Base Shipping Fee - Freeship Discount + Peak Surcharge)
× Order Validity
```

Trong C:

```c
float final_amount =
    (subtotal + base_shipping_fee - freeship_discount + peak_surcharge)
    * is_valid;
```

Nếu `is_valid = 1`, tổng tiền được giữ nguyên.

Nếu `is_valid = 0`, tổng tiền bằng `0 VNĐ`.

## 5. Xử lý lỗi bộ đệm khi nhập char

Loại tài khoản được nhập bằng:

```c
scanf(" %c", &loai_tai_khoan);
```

Dấu cách trước `%c` giúp bỏ qua ký tự xuống dòng còn lại sau các lần nhập dữ liệu số.

## 6. Các bước xử lý

1. Nhập toàn bộ dữ liệu đơn hàng.
2. Tính tiền món ăn `subtotal`.
3. Tính phí giao hàng cơ bản.
4. Kiểm tra điều kiện Freeship bằng toán tử so sánh và logic.
5. Tính số tiền giảm Freeship, không vượt quá phí giao hàng.
6. Tính phụ phí giờ cao điểm.
7. Kiểm tra tính hợp lệ của đơn hàng.
8. Tính tổng tiền cuối cùng bằng cách nhân với `is_valid`.
9. In phiếu thanh toán ra màn hình.

## 7. Test Case

### Test Case 1: Đơn hàng hợp lệ

Dữ liệu:

```text
Mã món = 1024
Đơn giá = 50000
Số lượng = 3
Khoảng cách = 4
Cao điểm = 1
Cửa hàng = 1
Tồn kho = 10
Tài khoản = V
```

Kết quả:

```text
Subtotal = 150000 VND
Phí giao hàng = 20000 VND
Giảm Freeship = 15000 VND
Phụ phí cao điểm = 10000 VND
Đơn hàng hợp lệ = 1
Tổng thanh toán = 165000 VND
```

### Test Case 2: Cửa hàng đóng cửa

Nếu `is_store_open = 0` thì:

```text
Đơn hàng hợp lệ = 0
Tổng thanh toán = 0 VND
```

### Test Case 3: Số lượng đặt bằng 0 hoặc âm

Nếu:

```text
so_luong_dat = 0
```

hoặc:

```text
so_luong_dat = -2
```

thì điều kiện `so_luong_dat > 0` sai.

Kết quả:

```text
Đơn hàng hợp lệ = 0
Tổng thanh toán = 0 VND
```

### Test Case 4: Đơn 20.000 VNĐ, khoảng cách 1 km, Normal

Dữ liệu:

```text
Subtotal = 20000
Khoảng cách = 1
Tài khoản = N
```

Vì:

```text
20000 < 100000
```

và:

```text
N != V
```

nên:

```text
is_freeship = 0
```

Đơn hàng không được giảm Freeship.

## 8. Phạm vi kiến thức

Chương trình chỉ sử dụng:
- `int`, `float`, `char`.
- `scanf()`, `printf()`.
- Toán tử số học.
- Toán tử so sánh.
- Toán tử logic.
- Giá trị Boolean `0` và `1`.

Không sử dụng:
- `if/else`.
- `switch`.
- `for`.
- `while`.
- `do-while`.
- Hàm tự định nghĩa.
- Mảng.
- `struct`.
